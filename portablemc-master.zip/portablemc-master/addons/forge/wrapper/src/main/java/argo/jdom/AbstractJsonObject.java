package argo.jdom;

abstract class AbstractJsonObject extends JsonRootNode {

}
