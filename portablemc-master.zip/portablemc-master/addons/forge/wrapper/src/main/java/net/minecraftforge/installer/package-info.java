/**
 * These packages are placeholders to allow 'portablemc.wrapper' classes to compile.
 * They are discarded from the final JAR file, and classes are dynamically imported
 * to avoid ClassNotFoundException while loading install runners.
 */
package net.minecraftforge.installer;
