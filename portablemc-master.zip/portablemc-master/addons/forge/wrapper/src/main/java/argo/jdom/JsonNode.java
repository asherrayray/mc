package argo.jdom;

import java.util.List;

public abstract class JsonNode {
	
	public abstract String getText();
	
	public abstract List<JsonField> getFieldList();
	
}
