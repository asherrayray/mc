package net.minecraftforge.installer.json;

public class InstallV1 extends Install {

}
