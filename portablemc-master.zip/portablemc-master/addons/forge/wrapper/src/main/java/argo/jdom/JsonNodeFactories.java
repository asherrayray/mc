package argo.jdom;

import java.util.Map;

public class JsonNodeFactories {
	
	public static JsonStringNode string(final String value) {
		return null;
	}
	
	public static JsonRootNode object(final Map<JsonStringNode, ? extends JsonNode> fields) {
		return null;
	}
	
}
